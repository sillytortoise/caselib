create table user_tb(
	uid char(20) primary key,
    pwd char(50)
    );
